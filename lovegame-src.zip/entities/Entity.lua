-- Base Entity

Entity = class( "Entity" )

function Entity:initialize()
end

function Entity:draw()
end

function Entity:update()
end
